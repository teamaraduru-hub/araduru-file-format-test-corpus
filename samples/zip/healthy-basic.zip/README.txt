ARADURU synthetic ZIP sample
